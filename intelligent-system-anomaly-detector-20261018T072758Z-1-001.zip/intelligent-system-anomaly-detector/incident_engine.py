import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd


# --------------------------------------------------
# FILE PATHS AND SETTINGS
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent

METRICS_FILE = BASE_DIR / "data" / "metrics.csv"
LOGS_FILE = BASE_DIR / "data" / "system_logs.jsonl"
MODEL_FILE = BASE_DIR / "models" / "anomaly_model.joblib"
OUTPUT_FILE = BASE_DIR / "data" / "incidents.json"

# Anomalies separated by no more than 30 seconds
# are grouped into the same incident.
GROUP_GAP_SECONDS = 30

# Include logs from 30 seconds before and after
# each incident's time window.
LOG_WINDOW_SECONDS = 30


# --------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------

def safe_number(value):
    """Convert a value to a JSON-safe number or None."""
    try:
        number = float(value)

        if not np.isfinite(number):
            return None

        return round(number, 3)

    except (TypeError, ValueError):
        return None


def read_system_logs():
    """Read JSONL system logs and parse their timestamps."""
    logs = []

    if not LOGS_FILE.exists():
        return logs

    with LOGS_FILE.open("r", encoding="utf-8") as file:
        for line in file:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            timestamp_text = (
                entry.get("timestamp")
                or entry.get("collected_at")
            )

            if not timestamp_text:
                continue

            timestamp = pd.to_datetime(
                timestamp_text,
                utc=True,
                errors="coerce",
            )

            if pd.isna(timestamp):
                continue

            entry["_parsed_timestamp"] = timestamp
            logs.append(entry)

    return logs


def group_anomalies(anomalies):
    """Group nearby anomalous observations into incidents."""
    if anomalies.empty:
        return []

    anomalies = anomalies.sort_values("timestamp")

    groups = []
    current_group = []
    previous_time = None

    for _, row in anomalies.iterrows():
        current_time = row["timestamp"]

        if previous_time is None:
            current_group = [row]
        else:
            gap = (
                current_time - previous_time
            ).total_seconds()

            if gap <= GROUP_GAP_SECONDS:
                current_group.append(row)
            else:
                groups.append(current_group)
                current_group = [row]

        previous_time = current_time

    if current_group:
        groups.append(current_group)

    return groups


def find_related_logs(start_time, end_time, logs):
    """Find logs close to an incident's time window."""
    window_start = start_time - pd.Timedelta(
        seconds=LOG_WINDOW_SECONDS
    )

    window_end = end_time + pd.Timedelta(
        seconds=LOG_WINDOW_SECONDS
    )

    matches = []

    for entry in logs:
        timestamp = entry["_parsed_timestamp"]

        if window_start <= timestamp <= window_end:
            priority_value = entry.get("priority")

            try:
                priority = int(priority_value)
            except (TypeError, ValueError):
                priority = None

            matches.append({
                "timestamp": timestamp.isoformat(),
                "priority": priority,
                "source": (
                    entry.get("unit")
                    or entry.get("identifier")
                    or "unknown"
                ),
                "message": str(
                    entry.get("message", "")
                )[:500],
            })

    # Show higher-priority events first, then chronological order.
    matches.sort(
        key=lambda item: (
            item["priority"]
            if item["priority"] is not None
            else 99,
            item["timestamp"],
        )
    )

    return matches[:30]


def assess_incident(rows):
    """
    Summarize metrics and suggest safe investigation steps.

    These rules indicate observed symptoms, not confirmed causes.
    """
    recommendations = []
    severity = "Low"

    cpu_values = rows["cpu_percent"].dropna()
    memory_values = rows["memory_percent"].dropna()
    swap_values = rows["swap_percent"].dropna()
    load_values = rows["load_1m"].dropna()
    available_values = rows["memory_available_mb"].dropna()

    max_cpu = (
        float(cpu_values.max())
        if not cpu_values.empty else None
    )

    max_memory = (
        float(memory_values.max())
        if not memory_values.empty else None
    )

    max_swap = (
        float(swap_values.max())
        if not swap_values.empty else None
    )

    max_load = (
        float(load_values.max())
        if not load_values.empty else None
    )

    min_available = (
        float(available_values.min())
        if not available_values.empty else None
    )

    if max_cpu is not None and max_cpu >= 90:
        severity = "High"
        recommendations.append({
            "signal": "CPU",
            "observation": (
                f"CPU usage reached {max_cpu:.1f}%."
            ),
            "action": (
                "Inspect CPU-intensive processes and "
                "check whether the workload is expected."
            ),
        })

    elif max_cpu is not None and max_cpu >= 75:
        severity = "Medium"
        recommendations.append({
            "signal": "CPU",
            "observation": (
                f"CPU usage reached {max_cpu:.1f}%."
            ),
            "action": (
                "Review CPU usage and check for "
                "unexpected workload increases."
            ),
        })

    if max_memory is not None and max_memory >= 90:
        severity = "High"
        recommendations.append({
            "signal": "Memory",
            "observation": (
                f"Memory usage reached {max_memory:.1f}%."
            ),
            "action": (
                "Inspect memory-intensive processes and "
                "check available memory before running "
                "additional workloads."
            ),
        })

    elif max_memory is not None and max_memory >= 80:
        if severity == "Low":
            severity = "Medium"

        recommendations.append({
            "signal": "Memory",
            "observation": (
                f"Memory usage reached {max_memory:.1f}%."
            ),
            "action": (
                "Monitor available memory and inspect "
                "process memory consumption."
            ),
        })

    if max_swap is not None and max_swap >= 25:
        if severity == "Low":
            severity = "Medium"

        recommendations.append({
            "signal": "Swap",
            "observation": (
                f"Swap usage reached {max_swap:.1f}%."
            ),
            "action": (
                "Check memory pressure and swap activity. "
                "Swap usage alone does not confirm a fault."
            ),
        })

    if min_available is not None and min_available < 500:
        severity = "High"
        recommendations.append({
            "signal": "Available memory",
            "observation": (
                "Available memory fell below 500 MB."
            ),
            "action": (
                "Check memory-intensive processes and "
                "avoid running memory stress tests."
            ),
        })

    if max_load is not None and max_load >= 4:
        if severity == "Low":
            severity = "Medium"

        recommendations.append({
            "signal": "System load",
            "observation": (
                f"One-minute load average reached {max_load:.2f}."
            ),
            "action": (
                "Compare system load with the number of "
                "available CPU cores and inspect running tasks."
            ),
        })

    if not recommendations:
        recommendations.append({
            "signal": "Unusual metric combination",
            "observation": (
                "The model detected unusual system behavior, "
                "but the configured resource thresholds "
                "were not crossed."
            ),
            "action": (
                "Review the metric values and related logs "
                "before deciding whether corrective action "
                "is necessary."
            ),
        })

    return {
        "severity": severity,
        "metrics": {
            "max_cpu_percent": safe_number(max_cpu),
            "max_memory_percent": safe_number(max_memory),
            "max_swap_percent": safe_number(max_swap),
            "max_load_1m": safe_number(max_load),
            "min_memory_available_mb": safe_number(
                min_available
            ),
        },
        "recommendations": recommendations,
    }


# --------------------------------------------------
# MAIN INCIDENT ANALYSIS
# --------------------------------------------------

def main():
    print("\n=== INTELLIGENT SYSTEM INCIDENT ENGINE ===")

    if not METRICS_FILE.exists():
        raise FileNotFoundError(
            f"Metrics file not found: {METRICS_FILE}"
        )

    if not MODEL_FILE.exists():
        raise FileNotFoundError(
            f"Trained model not found: {MODEL_FILE}"
        )

    df = pd.read_csv(METRICS_FILE)

    if "timestamp" not in df.columns:
        raise ValueError(
            "The metrics CSV must contain a timestamp column."
        )

    df["timestamp"] = pd.to_datetime(
        df["timestamp"],
        utc=True,
        errors="coerce",
    )

    df = df.dropna(subset=["timestamp"]).copy()
    df = df.sort_values("timestamp").reset_index(drop=True)

    model_data = joblib.load(MODEL_FILE)

    if not isinstance(model_data, dict):
        raise TypeError(
            "Unexpected model format. Expected a dictionary."
        )

    pipeline = model_data["pipeline"]
    features = model_data["features"]

    missing_features = [
        feature for feature in features
        if feature not in df.columns
    ]

    if missing_features:
        raise ValueError(
            f"Missing model features: {missing_features}"
        )

    X = df[features].apply(
        pd.to_numeric,
        errors="coerce",
    )

    X = X.replace([np.inf, -np.inf], np.nan)

    usable = X.notna().any(axis=1)

    df = df.loc[usable].copy().reset_index(drop=True)
    X = X.loc[usable].reset_index(drop=True)

    if X.empty:
        raise ValueError(
            "No usable metric observations were found."
        )

    predictions = pipeline.predict(X)
    anomaly_scores = -pipeline.decision_function(X)

    df["anomaly"] = predictions == -1
    df["anomaly_score"] = anomaly_scores

    anomalies = df[df["anomaly"]].copy()
    groups = group_anomalies(anomalies)
    logs = read_system_logs()

    incidents = []

    for index, group in enumerate(groups, start=1):
        group_df = pd.DataFrame(group).reset_index(drop=True)

        start_time = group_df["timestamp"].min()
        end_time = group_df["timestamp"].max()

        assessment = assess_incident(group_df)

        related_logs = find_related_logs(
            start_time,
            end_time,
            logs,
        )

        # A high-priority log is evidence for investigation,
        # not proof that the log caused the anomaly.
        incidents.append({
            "incident_id": f"INC-{index:04d}",
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "duration_seconds": round(
                (
                    end_time - start_time
                ).total_seconds(),
                2,
            ),
            "anomalous_observations": len(group_df),
            "highest_anomaly_score": safe_number(
                group_df["anomaly_score"].max()
            ),
            "severity": assessment["severity"],
            "observed_metrics": assessment["metrics"],
            "recommendations": assessment["recommendations"],
            "related_log_count": len(related_logs),
            "related_logs": related_logs,
            "root_cause_status": "Not confirmed",
        })

    result = {
        "generated_at": pd.Timestamp.now(
            tz="UTC"
        ).isoformat(),
        "model": model_data.get(
            "algorithm",
            "Unknown anomaly detection model",
        ),
        "observations_analyzed": len(df),
        "anomalous_observations": len(anomalies),
        "incident_count": len(incidents),
        "group_gap_seconds": GROUP_GAP_SECONDS,
        "log_window_seconds": LOG_WINDOW_SECONDS,
        "incidents": incidents,
        "limitations": [
            "Anomalies are grouped by timestamp proximity.",
            "Severity is based on configured metric thresholds.",
            "Related logs are temporal matches, not confirmed causes.",
            "Process-level evidence is not collected by this engine.",
        ],
    }

    OUTPUT_FILE.write_text(
        json.dumps(result, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    print("Observations analyzed:", len(df))
    print("Anomalous observations:", len(anomalies))
    print("Incidents created:", len(incidents))
    print("Log entries available:", len(logs))
    print("Report saved to:", OUTPUT_FILE)

    if not incidents:
        print("\nNo anomalies were detected in the current dataset.")

    for incident in incidents:
        print("\n" + "=" * 55)
        print(
            f"{incident['incident_id']} | "
            f"Severity: {incident['severity']}"
        )
        print("Start:", incident["start_time"])
        print("End:", incident["end_time"])
        print(
            "Anomalous observations:",
            incident["anomalous_observations"],
        )
        print(
            "Related log entries:",
            incident["related_log_count"],
        )

        for recommendation in incident["recommendations"]:
            print(
                f"- {recommendation['signal']}: "
                f"{recommendation['observation']}"
            )
            print(
                f"  Action: {recommendation['action']}"
            )


if __name__ == "__main__":
    main()
