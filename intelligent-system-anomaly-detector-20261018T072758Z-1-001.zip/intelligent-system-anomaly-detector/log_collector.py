import json
import os
import subprocess
from datetime import datetime, timezone

OUTPUT = "data/system_logs.jsonl"

os.makedirs("data", exist_ok=True)

command = [
    "journalctl",
    "--follow",
    "--lines=0",
    "--output=json",
    "--utc",
]

print("Collecting new system journal events.")
print(f"Output file: {OUTPUT}")
print("Press Ctrl+C to stop.")

try:
    with open(OUTPUT, "a", encoding="utf-8") as output:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )

        try:
            for line in process.stdout:
                try:
                    event = json.loads(line)

                    record = {
                        "collected_at": datetime.now(
                            timezone.utc
                        ).isoformat(),
                        "timestamp": event.get("__REALTIME_TIMESTAMP"),
                        "hostname": event.get("_HOSTNAME"),
                        "unit": event.get("_SYSTEMD_UNIT"),
                        "identifier": event.get("SYSLOG_IDENTIFIER"),
                        "priority": event.get("PRIORITY"),
                        "message": event.get("MESSAGE"),
                        "transport": event.get("_TRANSPORT"),
                    }

                    output.write(json.dumps(record) + "\n")
                    output.flush()

                    priority = record["priority"]
                    message = str(record["message"] or "")
                    print(f"[priority={priority}] {message[:150]}")

                except json.JSONDecodeError:
                    continue

        finally:
            process.terminate()
            process.wait(timeout=5)

except KeyboardInterrupt:
    print("\nSystem log collection stopped.")

except FileNotFoundError:
    print("journalctl was not found. Check your Ubuntu installation.")

except PermissionError:
    print("Permission denied. Check access to the system journal.")
