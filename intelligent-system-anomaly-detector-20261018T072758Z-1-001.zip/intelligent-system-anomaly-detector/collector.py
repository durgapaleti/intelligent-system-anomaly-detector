import csv
import os
import time
from datetime import datetime, timezone

import psutil

OUTPUT = "data/metrics.csv"
INTERVAL = 5

os.makedirs("data", exist_ok=True)

FIELDS = [
    "timestamp",
    "cpu_percent",
    "cpu_context_switches_per_sec",
    "cpu_interrupts_per_sec",
    "memory_percent",
    "memory_available_mb",
    "swap_percent",
    "swap_used_mb",
    "disk_percent",
    "disk_read_bytes_per_sec",
    "disk_write_bytes_per_sec",
    "network_recv_bytes_per_sec",
    "network_sent_bytes_per_sec",
    "network_packets_recv_per_sec",
    "network_packets_sent_per_sec",
    "network_errors",
    "network_drops",
    "process_count",
    "load_1m",
]

# Start fresh if the previous CSV has a different schema.
# Preserve the old file as a backup.
if os.path.exists(OUTPUT) and os.path.getsize(OUTPUT) > 0:
    with open(OUTPUT, "r", newline="") as f:
        existing_fields = next(csv.reader(f), [])

    if existing_fields != FIELDS:
        backup = OUTPUT + ".backup"
        os.replace(OUTPUT, backup)
        print(f"Previous metrics saved to {backup}")

# Record the first measurements.
previous_net = psutil.net_io_counters()
previous_disk = psutil.disk_io_counters()
previous_cpu = psutil.cpu_stats()
previous_time = time.monotonic()

print(f"Collecting extended metrics into {OUTPUT}")
print("Press Ctrl+C to stop.")

try:
    with open(OUTPUT, "a", newline="", buffering=1) as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)

        if f.tell() == 0:
            writer.writeheader()

        while True:
            start = time.monotonic()

            # CPU
            cpu_percent = psutil.cpu_percent(interval=1)
            current_cpu = psutil.cpu_stats()

            # Memory and swap
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()

            # Disk space and I/O
            disk_usage = psutil.disk_usage("/")
            current_disk = psutil.disk_io_counters()

            # Network
            current_net = psutil.net_io_counters()

            # Processes
            process_count = len(psutil.pids())

            # System load
            try:
                load_1m = os.getloadavg()[0]
            except (AttributeError, OSError):
                load_1m = 0.0

            # Calculate the measurement interval.
            now = time.monotonic()
            elapsed = max(now - previous_time, 0.001)

            def rate(current, previous):
                if current is None or previous is None:
                    return 0.0
                return max(0, current - previous) / elapsed

            disk_read = (
                rate(current_disk.read_bytes, previous_disk.read_bytes)
                if current_disk is not None and previous_disk is not None
                else 0.0
            )

            disk_write = (
                rate(current_disk.write_bytes, previous_disk.write_bytes)
                if current_disk is not None and previous_disk is not None
                else 0.0
            )

            network_recv = (
                rate(current_net.bytes_recv, previous_net.bytes_recv)
                if current_net is not None and previous_net is not None
                else 0.0
            )

            network_sent = (
                rate(current_net.bytes_sent, previous_net.bytes_sent)
                if current_net is not None and previous_net is not None
                else 0.0
            )

            packets_recv = (
                rate(current_net.packets_recv, previous_net.packets_recv)
                if current_net is not None and previous_net is not None
                else 0.0
            )

            packets_sent = (
                rate(current_net.packets_sent, previous_net.packets_sent)
                if current_net is not None and previous_net is not None
                else 0.0
            )

            errors = (
                current_net.errin + current_net.errout
                if current_net is not None else 0
            )

            drops = (
                current_net.dropin + current_net.dropout
                if current_net is not None else 0
            )

            writer.writerow({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "cpu_percent": cpu_percent,
                "cpu_context_switches_per_sec": rate(
                    current_cpu.ctx_switches,
                    previous_cpu.ctx_switches,
                ),
                "cpu_interrupts_per_sec": rate(
                    current_cpu.interrupts,
                    previous_cpu.interrupts,
                ),
                "memory_percent": memory.percent,
                "memory_available_mb": memory.available / (1024 ** 2),
                "swap_percent": swap.percent,
                "swap_used_mb": swap.used / (1024 ** 2),
                "disk_percent": disk_usage.percent,
                "disk_read_bytes_per_sec": disk_read,
                "disk_write_bytes_per_sec": disk_write,
                "network_recv_bytes_per_sec": network_recv,
                "network_sent_bytes_per_sec": network_sent,
                "network_packets_recv_per_sec": packets_recv,
                "network_packets_sent_per_sec": packets_sent,
                "network_errors": errors,
                "network_drops": drops,
                "process_count": process_count,
                "load_1m": load_1m,
            })

            # Update all previous measurements.
            previous_net = current_net
            previous_disk = current_disk
            previous_cpu = current_cpu
            previous_time = now

            print(
                f"CPU: {cpu_percent:5.1f}% | "
                f"RAM: {memory.percent:5.1f}% | "
                f"Swap: {swap.percent:5.1f}% | "
                f"Processes: {process_count} | "
                f"Network RX: {network_recv / 1024:.1f} KB/s"
            )

            remaining = INTERVAL - (time.monotonic() - start)
            if remaining > 0:
                time.sleep(remaining)

except KeyboardInterrupt:
    print("\nMetric collection stopped.")
