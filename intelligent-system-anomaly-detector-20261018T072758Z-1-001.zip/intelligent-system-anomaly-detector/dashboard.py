from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from advice_engine import create_advice


# ============================================================
# 1. PROJECT CONFIGURATION
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DATA_FILE = BASE_DIR / "data" / "metrics.csv"
LOG_FILE = BASE_DIR / "data" / "system_logs.jsonl"
MODEL_FILE = BASE_DIR / "models" / "anomaly_model.joblib"

st.set_page_config(
    page_title="Intelligent System Anomaly Detector",
    page_icon="🖥️",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ============================================================
# 2. DASHBOARD HEADER
# ============================================================

st.title("🖥️ Intelligent System Anomaly Detector")

st.markdown(
    """
    Monitor system performance, detect unusual behavior, investigate
    possible causes, and receive practical troubleshooting advice.
    """
)

with st.sidebar:
    st.header("Dashboard Controls")

    st.caption("Data refresh")

    if st.button("🔄 Refresh Dashboard", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

    st.divider()

    st.markdown("### Project Components")
    st.write("• System metrics collector")
    st.write("• Isolation Forest detector")
    st.write("• System journal collector")
    st.write("• Diagnosis and recommendation engine")

    st.divider()

    st.caption(
        "Recommendations are diagnostic suggestions. "
        "Verify the evidence before changing system settings."
    )


# ============================================================
# 3. LOAD METRICS
# ============================================================

@st.cache_data(ttl=5)
def load_metrics(file_path, modified_time):
    """Load collected system metrics."""

    del modified_time

    return pd.read_csv(file_path)


if not DATA_FILE.exists():
    st.error(
        "The metrics file was not found.\n\n"
        "Start the metrics collector using:\n\n"
        "`python collector.py`"
    )
    st.stop()

try:
    metrics = load_metrics(
        str(DATA_FILE),
        DATA_FILE.stat().st_mtime,
    )

except Exception as error:
    st.error(f"Could not read the metrics dataset: {error}")
    st.stop()

if metrics.empty:
    st.warning("No metric records have been collected yet.")
    st.stop()

if "timestamp" not in metrics.columns:
    st.error(
        "The metrics file does not contain a timestamp column. "
        "Check collector.py."
    )
    st.stop()

metrics["timestamp"] = pd.to_datetime(
    metrics["timestamp"],
    errors="coerce",
)

metrics = metrics.dropna(
    subset=["timestamp"]
).sort_values(
    "timestamp"
).reset_index(drop=True)

if metrics.empty:
    st.error(
        "No valid timestamps were found in the metrics dataset."
    )
    st.stop()


# ============================================================
# 4. LOAD THE TRAINED MODEL
# ============================================================

if not MODEL_FILE.exists():
    st.warning(
        "The trained model was not found. "
        "Train the model before using the dashboard."
    )

    st.code("python train_model.py")
    st.stop()

try:
    model_data = joblib.load(MODEL_FILE)

    if not isinstance(model_data, dict):
        st.error(
            "The saved model has an unsupported format. "
            "Use the train_model.py version that saves a dictionary "
            "containing 'pipeline' and 'features'."
        )
        st.stop()

    pipeline = model_data["pipeline"]
    features = model_data["features"]

except Exception as error:
    st.error(f"Could not load the trained model: {error}")
    st.stop()


# ============================================================
# 5. VALIDATE MODEL FEATURES
# ============================================================

missing_features = [
    feature
    for feature in features
    if feature not in metrics.columns
]

if missing_features:
    st.error(
        "The metrics dataset does not contain every feature "
        "required by the trained model."
    )

    st.write("Missing features:", missing_features)

    st.info(
        "Ensure collector.py generates the expected columns. "
        "If the collector's schema has changed, collect fresh data "
        "and retrain the model."
    )

    st.stop()


# ============================================================
# 6. PREPARE DATA FOR ANOMALY DETECTION
# ============================================================

data = metrics.copy()

X = data[features].copy()

for column in features:
    X[column] = pd.to_numeric(
        X[column],
        errors="coerce",
    )

X = X.replace(
    [np.inf, -np.inf],
    np.nan,
)

# Do not silently classify records where every feature is missing.
usable_rows = X.notna().any(axis=1)

data = data.loc[usable_rows].copy().reset_index(drop=True)
X = X.loc[usable_rows].copy().reset_index(drop=True)

if X.empty:
    st.error(
        "No usable metric records are available for prediction."
    )
    st.stop()

# The fitted preprocessing pipeline imputes missing feature values.
try:
    predictions = pipeline.predict(X)

    # For Isolation Forest, a lower decision_function value
    # means the observation is more unusual.
    decision_values = pipeline.decision_function(X)

except Exception as error:
    st.error(
        "The model could not process the metrics dataset. "
        f"Details: {error}"
    )
    st.stop()

data["anomaly"] = predictions == -1

# Larger values in this column indicate more unusual observations.
data["anomaly_score"] = -decision_values

data["status"] = np.where(
    data["anomaly"],
    "Anomaly",
    "Normal",
)


# ============================================================
# 7. LATEST METRICS AND SUMMARY
# ============================================================

latest = data.iloc[-1]

total_records = len(data)
total_anomalies = int(data["anomaly"].sum())
normal_records = total_records - total_anomalies

anomaly_rate = (
    total_anomalies / total_records * 100
    if total_records
    else 0.0
)

st.subheader("📊 System Overview")

col1, col2, col3, col4 = st.columns(4)


def display_metric(metric_name, label, suffix=""):
    """Display a metric safely."""

    if metric_name not in latest.index:
        return "N/A"

    try:
        value = float(latest[metric_name])

        if not np.isfinite(value):
            return "N/A"

        return f"{value:.1f}{suffix}"

    except (TypeError, ValueError):
        return "N/A"


col1.metric(
    "CPU Usage",
    display_metric("cpu_percent", "CPU", "%"),
)

col2.metric(
    "Memory Usage",
    display_metric("memory_percent", "Memory", "%"),
)

col3.metric(
    "Detected Anomalies",
    f"{total_anomalies:,}",
)

col4.metric(
    "Dataset Anomaly Rate",
    f"{anomaly_rate:.2f}%",
)

st.caption(
    f"Records analyzed: {total_records:,} | "
    f"Normal predictions: {normal_records:,} | "
    f"Latest sample: {latest['timestamp']}"
)

st.info(
    "The anomaly rate is the proportion of records flagged in the "
    "currently loaded dataset. It is not the probability that the "
    "system has failed."
)


# ============================================================
# 8. LATEST OBSERVATION
# ============================================================

st.subheader("🔎 Latest System Observation")

if bool(latest["anomaly"]):
    st.warning(
        "The model flagged the latest observation as unusual. "
        "Review the metrics and related system logs."
    )
else:
    st.success(
        "The latest observation was not flagged by the anomaly detector."
    )

latest_details = []

display_metrics = [
    ("cpu_percent", "CPU Usage", "%"),
    ("cpu_context_switches_per_sec", "Context Switches per Second", ""),
    ("cpu_interrupts_per_sec", "Interrupts per Second", ""),
    ("memory_percent", "Memory Usage", "%"),
    ("memory_available_mb", "Available Memory", " MB"),
    ("swap_percent", "Swap Usage", "%"),
    ("swap_used_mb", "Swap Used", " MB"),
    ("disk_percent", "Disk Usage", "%"),
    ("disk_read_bytes_per_sec", "Disk Read Throughput", " bytes/s"),
    ("disk_write_bytes_per_sec", "Disk Write Throughput", " bytes/s"),
    ("network_recv_bytes_per_sec", "Network Received", " bytes/s"),
    ("network_sent_bytes_per_sec", "Network Sent", " bytes/s"),
    ("network_packets_recv_per_sec", "Packets Received per Second", ""),
    ("network_packets_sent_per_sec", "Packets Sent per Second", ""),
    ("network_errors", "Network Errors Counter", ""),
    ("network_drops", "Network Drops Counter", ""),
    ("process_count", "Process Count", ""),
    ("load_1m", "One-Minute Load Average", ""),
]

for column, label, suffix in display_metrics:
    if column not in data.columns:
        continue

    try:
        value = float(latest[column])

        if not np.isfinite(value):
            formatted = "N/A"
        elif suffix == " bytes/s":
            formatted = f"{value:,.0f}{suffix}"
        else:
            formatted = f"{value:.2f}{suffix}"

    except (TypeError, ValueError):
        formatted = "N/A"

    latest_details.append({
        "Metric": label,
        "Value": formatted,
    })

if latest_details:
    st.dataframe(
        pd.DataFrame(latest_details),
        use_container_width=True,
        hide_index=True,
    )


# ============================================================
# 9. LOAD RECENT SYSTEM LOGS
# ============================================================

@st.cache_data(ttl=5)
def load_system_logs(file_path, modified_time, file_size):
    """Read valid JSON objects from the system log file."""

    del modified_time, file_size

    path = Path(file_path)

    if not path.exists():
        return []

    records = []

    # Read only a limited amount of data for the dashboard.
    with path.open(
        "r",
        encoding="utf-8",
        errors="replace",
    ) as log_file:
        lines = log_file.readlines()[-1000:]

    for line in lines:
        try:
            record = json.loads(line)

            if isinstance(record, dict):
                records.append(record)

        except json.JSONDecodeError:
            continue

    return records


recent_logs = []

if LOG_FILE.exists():
    try:
        recent_logs = load_system_logs(
            str(LOG_FILE),
            LOG_FILE.stat().st_mtime,
            LOG_FILE.stat().st_size,
        )

    except OSError as error:
        st.warning(f"Could not read system logs: {error}")


# ============================================================
# 10. SYSTEM DIAGNOSIS AND RECOMMENDATIONS
# ============================================================

st.subheader("🧠 System Diagnosis and Recommended Actions")

latest_metrics = latest.to_dict()

latest_score = latest.get(
    "anomaly_score",
    None,
)

try:
    diagnosis = create_advice(
        metrics=latest_metrics,
        is_anomaly=bool(latest["anomaly"]),
        anomaly_score=latest_score,
        system_logs=recent_logs,
    )

except Exception as error:
    diagnosis = None
    st.error(
        "The recommendation engine encountered an error: "
        f"{error}"
    )

if diagnosis:
    st.caption(
        "Advice is generated from the latest metrics, model prediction, "
        "and collected system logs. Possible causes are hypotheses, "
        "not confirmed root causes."
    )

    st.write(
        f"**Diagnosis generated:** {diagnosis['generated_at']}"
    )

    recommendations = diagnosis.get(
        "recommendations",
        [],
    )

    if recommendations:
        for item in recommendations:
            severity = item.get(
                "severity",
                "Info",
            )

            title = item.get(
                "title",
                "System observation",
            )

            with st.expander(
                f"{severity} — {title}",
                expanded=severity in ["High", "Review"],
            ):
                st.markdown("**Observed evidence**")
                st.write(
                    item.get(
                        "observation",
                        "No observation details available.",
                    )
                )

                st.markdown("**Possible causes**")

                for cause in item.get(
                    "possible_causes",
                    [],
                ):
                    st.markdown(f"- {cause}")

                st.markdown("**Recommended actions**")

                for action in item.get(
                    "recommended_actions",
                    [],
                ):
                    st.markdown(f"- {action}")

                examples = item.get(
                    "log_examples",
                    [],
                )

                if examples:
                    st.markdown("**Related log events**")

                    for log in examples:
                        st.markdown(
                            f"- **Service:** "
                            f"{log.get('unit', 'Unknown')} | "
                            f"**Priority:** "
                            f"{log.get('priority', 'Unknown')}  \n"
                            f"  {log.get('message', '')}"
                        )

    else:
        st.info("The recommendation engine returned no advice.")


# ============================================================
# 11. CPU AND MEMORY USAGE CHART
# ============================================================

st.subheader("📈 CPU and Memory Usage")

resource_columns = [
    column
    for column in [
        "cpu_percent",
        "memory_percent",
    ]
    if column in data.columns
]

if resource_columns:
    resource_data = data[
        ["timestamp"] + resource_columns
    ].copy()

    resource_data = resource_data.dropna(
        subset=["timestamp"]
    )

    for column in resource_columns:
        resource_data[column] = pd.to_numeric(
            resource_data[column],
            errors="coerce",
        )

    resource_long = resource_data.melt(
        id_vars=["timestamp"],
        var_name="Metric",
        value_name="Usage (%)",
    ).dropna(
        subset=["Usage (%)"]
    )

    if not resource_long.empty:
        fig_resources = px.line(
            resource_long,
            x="timestamp",
            y="Usage (%)",
            color="Metric",
            title="CPU and Memory Usage Over Time",
        )

        fig_resources.update_layout(
            xaxis_title="Time",
            yaxis_title="Usage (%)",
            legend_title="Metric",
        )

        st.plotly_chart(
            fig_resources,
            use_container_width=True,
        )

else:
    st.info("CPU and memory metrics are not available.")
# --------------------------------------------------
# INCIDENT CORRELATION REPORT
# --------------------------------------------------

st.divider()
st.header("Incident Investigation")

incident_file = (
    Path(__file__).resolve().parent
    / "data"
    / "incidents.json"
)

if not incident_file.exists():
    st.info(
        "No incident report found. "
        "Run `python incident_engine.py` first."
    )
else:
    try:
        with incident_file.open("r", encoding="utf-8") as file:
            incident_data = json.load(file)

        incidents = incident_data.get("incidents", [])

        # Overall incident statistics
        col1, col2, col3 = st.columns(3)

        col1.metric(
            "Observations Analyzed",
            incident_data.get("observations_analyzed", 0),
        )

        col2.metric(
            "Anomalous Observations",
            incident_data.get("anomalous_observations", 0),
        )

        col3.metric(
            "Incidents Identified",
            incident_data.get("incident_count", 0),
        )

        st.caption(
            "Report generated: "
            + str(incident_data.get("generated_at", "Unknown"))
        )

        if not incidents:
            st.success(
                "No anomalous incidents were found in the "
                "data analyzed by the incident engine."
            )

        for incident in incidents:
            title = (
                f"{incident.get('incident_id', 'Incident')} | "
                f"{incident.get('severity', 'Unknown')} Severity | "
                f"{incident.get('anomalous_observations', 0)} "
                f"anomalous observations"
            )

            with st.expander(title):
                st.write(
                    "**Start:**",
                    incident.get("start_time", "Unknown"),
                )

                st.write(
                    "**End:**",
                    incident.get("end_time", "Unknown"),
                )

                st.write(
                    "**Duration:**",
                    f"{incident.get('duration_seconds', 0)} seconds",
                )

                st.write(
                    "**Related log entries:**",
                    incident.get("related_log_count", 0),
                )

                st.write(
                    "**Root cause status:**",
                    incident.get("root_cause_status", "Not confirmed"),
                )

                st.subheader("Observed Metrics")

                observed_metrics = incident.get(
                    "observed_metrics", {}
                )

                if observed_metrics:
                    metrics_df = pd.DataFrame(
                        [
                            {
                                "Metric": name,
                                "Observed Value": value,
                            }
                            for name, value in observed_metrics.items()
                        ]
                    )

                    st.dataframe(
                        metrics_df,
                        hide_index=True,
                        use_container_width=True,
                    )

                st.subheader("Recommended Actions")

                recommendations = incident.get(
                    "recommendations", []
                )

                for recommendation in recommendations:
                    st.markdown(
                        f"**{recommendation.get('signal', 'System')}**"
                    )

                    st.write(
                        recommendation.get(
                            "observation",
                            "No observation available.",
                        )
                    )

                    st.write(
                        "Recommended action: "
                        + recommendation.get(
                            "action",
                            "Investigate the incident.",
                        )
                    )

                st.subheader("Related System Logs")

                related_logs = incident.get("related_logs", [])

                if not related_logs:
                    st.info(
                        "No log entries were collected for this "
                        "incident's time window. This does not prove "
                        "that no relevant system events occurred."
                    )
                else:
                    for log in related_logs:
                        st.write(
                            f"**{log.get('timestamp', 'Unknown')}** "
                            f"| Priority: "
                            f"{log.get('priority', 'Unknown')} "
                            f"| Source: "
                            f"{log.get('source', 'Unknown')}"
                        )

                        st.code(
                            log.get("message", ""),
                            language=None,
                        )

        # Downloadable report
        st.download_button(
            label="Download Incident Report (JSON)",
            data=json.dumps(incident_data, indent=2),
            file_name="incident_report.json",
            mime="application/json",
        )

    except (OSError, json.JSONDecodeError) as exc:
        st.error(f"Could not read the incident report: {exc}")

# ============================================================
# 12. DISK AND NETWORK ACTIVITY
# ============================================================

st.subheader("💾 Disk and Network Activity")

activity_columns = [
    column
    for column in [
        "disk_read_bytes_per_sec",
        "disk_write_bytes_per_sec",
        "network_recv_bytes_per_sec",
        "network_sent_bytes_per_sec",
    ]
    if column in data.columns
]

if activity_columns:
    activity_data = data[
        ["timestamp"] + activity_columns
    ].copy()

    activity_data = activity_data.dropna(
        subset=["timestamp"]
    )

    for column in activity_columns:
        activity_data[column] = pd.to_numeric(
            activity_data[column],
            errors="coerce",
        )

    activity_long = activity_data.melt(
        id_vars=["timestamp"],
        var_name="Metric",
        value_name="Bytes per Second",
    ).dropna(
        subset=["Bytes per Second"]
    )

    if not activity_long.empty:
        fig_activity = px.line(
            activity_long,
            x="timestamp",
            y="Bytes per Second",
            color="Metric",
            title="Disk and Network Throughput",
        )

        fig_activity.update_layout(
            xaxis_title="Time",
            yaxis_title="Bytes per Second",
            legend_title="Metric",
        )

        st.plotly_chart(
            fig_activity,
            use_container_width=True,
        )

else:
    st.info("Disk and network throughput metrics are unavailable.")


# ============================================================
# 13. ANOMALY TIMELINE
# ============================================================

st.subheader("🚨 Anomaly Detection Timeline")

timeline_data = data.dropna(
    subset=["timestamp"]
).copy()

if not timeline_data.empty:
    fig_timeline = px.scatter(
        timeline_data,
        x="timestamp",
        y="anomaly_score",
        color="status",
        hover_data=[
            column
            for column in [
                "cpu_percent",
                "memory_percent",
                "disk_percent",
                "load_1m",
            ]
            if column in timeline_data.columns
        ],
        title="Unusual System Behavior Over Time",
    )

    fig_timeline.update_layout(
        xaxis_title="Time",
        yaxis_title="Anomaly Score (higher = more unusual)",
        legend_title="Prediction",
    )

    st.plotly_chart(
        fig_timeline,
        use_container_width=True,
    )


# ============================================================
# 14. RECENT ANOMALIES
# ============================================================

st.subheader("⚠️ Recent Anomalies")

anomalies = data[
    data["anomaly"]
].copy()

if anomalies.empty:
    st.info(
        "No records have been flagged as anomalies in the current dataset."
    )

else:
    recent_anomalies = anomalies.tail(20).iloc[::-1]

    anomaly_columns = [
        column
        for column in [
            "timestamp",
            "cpu_percent",
            "memory_percent",
            "disk_percent",
            "swap_percent",
            "network_recv_bytes_per_sec",
            "network_sent_bytes_per_sec",
            "load_1m",
            "anomaly_score",
            "status",
        ]
        if column in recent_anomalies.columns
    ]

    st.dataframe(
        recent_anomalies[anomaly_columns],
        use_container_width=True,
        hide_index=True,
    )


# ============================================================
# 15. SYSTEM JOURNAL EVENTS
# ============================================================

st.subheader("📋 Recent System Log Events")

if not LOG_FILE.exists():
    st.info(
        "No system log file was found. Start log_collector.py "
        "to collect new journal events."
    )

elif not recent_logs:
    st.info(
        "The system log file contains no readable JSON events yet."
    )

else:
    logs = pd.DataFrame(recent_logs)

    # Show the most recent events first.
    logs = logs.tail(100).iloc[::-1].copy()

    log_columns = [
        column
        for column in [
            "collected_at",
            "timestamp",
            "hostname",
            "unit",
            "identifier",
            "priority",
            "message",
        ]
        if column in logs.columns
    ]

    if log_columns:
        st.dataframe(
            logs[log_columns],
            use_container_width=True,
            hide_index=True,
        )

    st.caption(
        "The log collector records new events after it starts. "
        "The displayed events are supporting evidence, not proof "
        "of the cause of an anomaly."
    )


# ============================================================
# 16. ALL COLLECTED METRICS
# ============================================================

with st.expander("📚 View All Collected Metrics"):
    st.dataframe(
        data.iloc[::-1],
        use_container_width=True,
        hide_index=True,
    )


# ============================================================
# 17. FOOTER
# ============================================================

st.divider()

st.caption(
    "Intelligent System Anomaly Detector | "
    "Isolation Forest | System Diagnostics | "
    "Evidence-Based Recommendations"
)
