from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from sklearn.ensemble import IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


# --------------------------------------------------
# 1. Project paths
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent

DATA_FILE = BASE_DIR / "data" / "metrics.csv"
MODEL_DIR = BASE_DIR / "models"
MODEL_FILE = MODEL_DIR / "anomaly_model.joblib"


# --------------------------------------------------
# 2. Features collected by collector.py
# --------------------------------------------------

FEATURES = [
    "cpu_percent",
    "cpu_context_switches_per_sec",
    "cpu_interrupts_per_sec",
    "memory_percent",
    "memory_available_mb",
    "swap_percent",
    "swap_used_mb",
    "disk_percent",
    "disk_read_bytes_per_sec",
    "disk_write_bytes_per_sec",
    "network_recv_bytes_per_sec",
    "network_sent_bytes_per_sec",
    "network_packets_recv_per_sec",
    "network_packets_sent_per_sec",
    "network_errors",
    "network_drops",
    "process_count",
    "load_1m",
]


# --------------------------------------------------
# 3. Model configuration
# --------------------------------------------------

MIN_RECORDS = 100

# Initial assumption: approximately 3% of training
# records may be anomalies. Validate this assumption
# against normal operating data and controlled tests.
CONTAMINATION = 0.03

RANDOM_STATE = 42


# --------------------------------------------------
# 4. Load and validate the dataset
# --------------------------------------------------

def load_dataset():
    """Load system metrics and validate required columns."""

    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATA_FILE}\n"
            "Run collector.py first to collect system metrics."
        )

    print("=" * 60)
    print("INTELLIGENT SYSTEM ANOMALY DETECTOR")
    print("=" * 60)

    print(f"\nLoading dataset: {DATA_FILE}")

    df = pd.read_csv(DATA_FILE)

    if df.empty:
        raise ValueError(
            "The metrics dataset is empty. "
            "Run collector.py and collect data first."
        )

    # Check required feature columns.
    missing_columns = [
        column for column in FEATURES
        if column not in df.columns
    ]

    if missing_columns:
        raise ValueError(
            "The dataset is missing required columns:\n"
            f"{missing_columns}\n\n"
            "Check that collector.py writes all 18 expected "
            "features and that metrics.csv was generated "
            "using the updated collector."
        )

    print(f"Total CSV records: {len(df)}")

    # Convert feature values to numbers.
    # Invalid strings become NaN and are handled below.
    X = df[FEATURES].copy()

    for column in FEATURES:
        X[column] = pd.to_numeric(
            X[column],
            errors="coerce"
        )

    # Replace positive and negative infinity with NaN.
    X = X.replace([np.inf, -np.inf], np.nan)

    # Remove records where every feature is missing.
    valid_rows = X.notna().any(axis=1)

    removed_rows = int((~valid_rows).sum())

    X = X.loc[valid_rows].reset_index(drop=True)

    if removed_rows:
        print(
            f"Records removed because all features were "
            f"invalid or missing: {removed_rows}"
        )

    if X.empty:
        raise ValueError(
            "No usable metric records remain after cleaning."
        )

    # Remove constant features, since they provide no
    # variation for distinguishing observations.
    constant_features = [
        column
        for column in X.columns
        if X[column].nunique(dropna=True) <= 1
    ]

    if constant_features:
        print(
            "\nFeatures with no variation in this dataset:"
        )

        for column in constant_features:
            print(f"  - {column}")

        X = X.drop(columns=constant_features)

    if X.shape[1] == 0:
        raise ValueError(
            "All features are constant or unusable. "
            "Collect more varied system metrics."
        )

    # Require enough usable observations for training.
    if len(X) < MIN_RECORDS:
        raise ValueError(
            f"Only {len(X)} usable records are available.\n"
            f"At least {MIN_RECORDS} records are required.\n"
            "Continue running collector.py before training."
        )

    # Imputation is handled inside the model pipeline.
    # Drop features that are entirely missing because
    # there is no value from which to calculate a median.
    all_missing_features = [
        column
        for column in X.columns
        if X[column].isna().all()
    ]

    if all_missing_features:
        print(
            "\nFeatures with no valid observations:"
        )

        for column in all_missing_features:
            print(f"  - {column}")

        X = X.drop(columns=all_missing_features)

    if X.shape[1] == 0:
        raise ValueError(
            "All selected features contain missing values."
        )

    print(f"Usable records: {len(X)}")
    print(f"Features used: {len(X.columns)}")

    print("\nFeatures selected for training:")

    for column in X.columns:
        print(f"  - {column}")

    print("\nMissing values per feature:")

    missing_counts = X.isna().sum()

    if missing_counts.sum() == 0:
        print("  No missing values.")
    else:
        for column, count in missing_counts.items():
            if count > 0:
                print(f"  {column}: {count}")

    return X


# --------------------------------------------------
# 5. Build the Isolation Forest pipeline
# --------------------------------------------------

def build_model():
    """Create the preprocessing and anomaly detection pipeline."""

    pipeline = Pipeline(
        steps=[
            (
                "imputer",
                SimpleImputer(strategy="median"),
            ),
            (
                "scaler",
                StandardScaler(),
            ),
            (
                "isolation_forest",
                IsolationForest(
                    n_estimators=200,
                    contamination=CONTAMINATION,
                    random_state=RANDOM_STATE,
                    n_jobs=-1,
                ),
            ),
        ]
    )

    return pipeline


# --------------------------------------------------
# 6. Train the model
# --------------------------------------------------

def train_model(X):
    """Train Isolation Forest using collected system metrics."""

    print("\n" + "=" * 60)
    print("TRAINING ISOLATION FOREST")
    print("=" * 60)

    pipeline = build_model()

    pipeline.fit(X)

    print("\nTraining completed successfully.")

    return pipeline


# --------------------------------------------------
# 7. Evaluate training predictions
# --------------------------------------------------

def evaluate_model(pipeline, X):
    """
    Summarize training-set anomaly predictions.

    These are training diagnostics, not an independent
    evaluation of real-world anomaly detection accuracy.
    """

    predictions = pipeline.predict(X)

    normal_count = int(np.sum(predictions == 1))
    anomaly_count = int(np.sum(predictions == -1))

    anomaly_percentage = (
        anomaly_count / len(predictions)
    ) * 100

    print("\n" + "=" * 60)
    print("TRAINING DATA SUMMARY")
    print("=" * 60)

    print(f"Total records: {len(predictions)}")
    print(f"Predicted normal records: {normal_count}")
    print(f"Predicted anomalies: {anomaly_count}")
    print(
        f"Predicted anomaly percentage: "
        f"{anomaly_percentage:.2f}%"
    )

    print(
        "\nNote: These predictions describe the training "
        "data. They do not prove the model's accuracy."
    )


# --------------------------------------------------
# 8. Save the model and metadata
# --------------------------------------------------

def save_model(pipeline, X):
    """Save the fitted pipeline and the feature names it expects."""

    MODEL_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    model_data = {
        "pipeline": pipeline,
        "features": list(X.columns),
        "contamination": CONTAMINATION,
        "algorithm": "IsolationForest",
        "n_estimators": 200,
        "random_state": RANDOM_STATE,
    }

    joblib.dump(
        model_data,
        MODEL_FILE
    )

    print("\n" + "=" * 60)
    print("MODEL SAVED")
    print("=" * 60)

    print(f"Model path: {MODEL_FILE}")
    print(f"File size: {MODEL_FILE.stat().st_size / 1024:.2f} KB")


# --------------------------------------------------
# 9. Main execution
# --------------------------------------------------

def main():
    try:
        # Load and clean the metrics.
        X = load_dataset()

        # Build and train the pipeline.
        pipeline = train_model(X)

        # Summarize predictions on training data.
        evaluate_model(pipeline, X)

        # Save the trained pipeline and metadata.
        save_model(pipeline, X)

        print("\nTraining process completed successfully.")
        print(
            "Next step: connect anomaly predictions "
            "to dashboard.py."
        )

    except (FileNotFoundError, ValueError) as error:
        print(f"\nERROR: {error}")
        raise SystemExit(1)

    except Exception as error:
        print(
            "\nAn unexpected error occurred during training:"
        )
        print(f"{type(error).__name__}: {error}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
