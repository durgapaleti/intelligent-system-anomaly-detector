# Intelligent System Anomaly Detector

An intelligent system monitoring tool that detects unusual system resource usage, analyzes system logs, groups anomalies into incidents, and provides recommendations to help investigate potential system problems.

## Overview

System performance problems can occur when CPU usage, memory consumption, swap usage, disk activity, or network activity behaves unusually. Identifying these problems manually can be difficult, especially when multiple metrics change at the same time.

The Intelligent System Anomaly Detector monitors system metrics, uses machine learning to identify unusual patterns, and generates incident reports to support system investigation.

The project combines machine learning, system monitoring, log collection, and an interactive dashboard to provide a simple system anomaly investigation workflow.

## Key Features

- **Real-Time System Monitoring:** Collects CPU, memory, swap, disk, network, process, and system load metrics.
- **Machine Learning-Based Detection:** Uses the Isolation Forest algorithm to identify unusual combinations of system metrics.
- **System Log Collection:** Collects new system journal events for additional investigation context.
- **Incident Grouping:** Groups nearby anomalous observations into incidents based on their timestamps.
- **Metric and Log Correlation:** Associates available system log entries with incidents occurring around similar times.
- **Severity Assessment:** Assigns incident severity using predefined rules and observed resource usage.
- **Actionable Recommendations:** Provides suggestions for investigating potential resource pressure and unusual activity.
- **Interactive Dashboard:** Displays metrics, anomaly information, system logs, incident summaries, and recommendations.
- **Incident Reports:** Saves incident investigation results as a JSON file.

## Technology Stack

| Component | Technology |
|---|---|
| Programming Language | Python |
| System Monitoring | psutil |
| Data Processing | Pandas, NumPy |
| Machine Learning | Scikit-learn |
| Anomaly Detection | Isolation Forest |
| Model Persistence | Joblib |
| Dashboard | Streamlit |
| Data Visualization | Plotly |
| System Logs | Linux systemd journal |
| Data Storage | CSV and JSON |
| Development Environment | Ubuntu Linux |

## System Architecture

The project follows this workflow:

1. **Metric Collection:** Collects system performance metrics periodically.
2. **Log Collection:** Captures new system journal events.
3. **Data Processing:** Reads and prepares the collected metrics for analysis.
4. **Anomaly Detection:** Applies the trained Isolation Forest model to identify unusual observations.
5. **Incident Analysis:** Groups nearby anomalies and examines available logs around the incident period.
6. **Severity and Recommendations:** Uses rule-based logic to estimate severity and suggest investigation steps.
7. **Dashboard and Reporting:** Displays the results through a Streamlit dashboard and stores incident reports in JSON format.

## Project Structure

```text
intelligent-system-anomaly-detector/
│
├── data/
│   ├── metrics.csv
│   ├── system_logs.jsonl
│   └── incidents.json
│
├── models/
│   └── anomaly_model.joblib
│
├── collector.py
├── log_collector.py
├── train_model.py
├── advice_engine.py
├── incident_engine.py
├── dashboard.py
├── requirements.txt
└── README.md
