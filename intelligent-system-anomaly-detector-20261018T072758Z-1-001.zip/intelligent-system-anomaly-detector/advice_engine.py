from datetime import datetime, timezone


def safe_float(metrics, name, default=None):
    """Read a numeric metric safely."""

    try:
        value = metrics.get(name, default)

        if value is None:
            return default

        value = float(value)

        if value != value or value in (float("inf"), float("-inf")):
            return default

        return value

    except (TypeError, ValueError):
        return default


def create_advice(
    metrics,
    is_anomaly=False,
    anomaly_score=None,
    system_logs=None,
):
    """
    Analyze the latest system metrics and return
    possible diagnoses and recommended actions.

    metrics:
        Dictionary containing the latest metric values.

    is_anomaly:
        True if the trained Isolation Forest flagged
        the latest observation.

    anomaly_score:
        Optional Isolation Forest anomaly score.

    system_logs:
        Optional list of recent system log dictionaries.
    """

    advice = []

    cpu = safe_float(metrics, "cpu_percent")
    memory = safe_float(metrics, "memory_percent")
    available_memory = safe_float(metrics, "memory_available_mb")
    swap = safe_float(metrics, "swap_percent")
    disk = safe_float(metrics, "disk_percent")
    load = safe_float(metrics, "load_1m")
    network_in = safe_float(metrics, "network_recv_bytes_per_sec")
    network_out = safe_float(metrics, "network_sent_bytes_per_sec")
    disk_read = safe_float(metrics, "disk_read_bytes_per_sec")
    disk_write = safe_float(metrics, "disk_write_bytes_per_sec")
    network_errors = safe_float(metrics, "network_errors")
    network_drops = safe_float(metrics, "network_drops")

    # --------------------------------------------------
    # 1. CPU diagnosis
    # --------------------------------------------------

    if cpu is not None and cpu >= 90:
        advice.append({
            "severity": "High",
            "title": "Very high CPU utilization",
            "observation": (
                f"CPU utilization is {cpu:.1f}%. "
                "The processor may be under heavy load."
            ),
            "possible_causes": [
                "A CPU-intensive process",
                "A large workload or background task",
                "A process that is stuck or repeatedly retrying work",
            ],
            "recommended_actions": [
                "Run `top` to identify processes consuming CPU.",
                "Run `ps -eo pid,comm,%cpu,%mem --sort=-%cpu | head` "
                "to list CPU-intensive processes.",
                "Check whether the high usage continues over several samples.",
                "If a known application is responsible, investigate its workload "
                "and logs before restarting it.",
            ],
        })

    elif cpu is not None and cpu >= 75:
        advice.append({
            "severity": "Medium",
            "title": "Elevated CPU utilization",
            "observation": (
                f"CPU utilization is {cpu:.1f}%, which may indicate "
                "a busy system."
            ),
            "possible_causes": [
                "A demanding application",
                "Background processing",
                "Several processes running at the same time",
            ],
            "recommended_actions": [
                "Run `top` to inspect CPU usage by process.",
                "Compare CPU usage across several samples.",
                "Check whether system responsiveness has degraded.",
            ],
        })

    # --------------------------------------------------
    # 2. Memory diagnosis
    # --------------------------------------------------

    if memory is not None and memory >= 95:
        advice.append({
            "severity": "High",
            "title": "Critical memory pressure possible",
            "observation": (
                f"Memory usage is {memory:.1f}%. "
                "The system may have limited available RAM."
            ),
            "possible_causes": [
                "Applications using large amounts of memory",
                "Several memory-intensive applications",
                "A possible memory leak",
            ],
            "recommended_actions": [
                "Run `free -h` to inspect available memory and swap.",
                "Run `ps -eo pid,comm,%mem,rss --sort=-%mem | head` "
                "to identify memory-intensive processes.",
                "Check whether memory consumption keeps increasing over time.",
                "Save your work before closing any application.",
            ],
        })

    elif memory is not None and memory >= 85:
        advice.append({
            "severity": "Medium",
            "title": "High memory utilization",
            "observation": (
                f"Memory usage is {memory:.1f}%. "
                "Check whether the system has sufficient available memory."
            ),
            "possible_causes": [
                "Multiple applications using memory",
                "A large dataset or workload",
                "An application retaining memory longer than expected",
            ],
            "recommended_actions": [
                "Run `free -h` to inspect memory availability.",
                "Use `top` to find memory-intensive processes.",
                "Monitor memory usage to determine whether it is temporary "
                "or persistent.",
            ],
        })

    if available_memory is not None and available_memory < 200:
        advice.append({
            "severity": "High",
            "title": "Very low available memory",
            "observation": (
                f"Available memory is approximately "
                f"{available_memory:.0f} MB."
            ),
            "possible_causes": [
                "Heavy application memory consumption",
                "Insufficient RAM for the current workload",
            ],
            "recommended_actions": [
                "Run `free -h` and inspect available memory.",
                "Check the largest memory-consuming processes.",
                "Avoid starting additional memory-intensive tasks until "
                "the situation is understood.",
            ],
        })

    # --------------------------------------------------
    # 3. Swap diagnosis
    # --------------------------------------------------

    if swap is not None and swap >= 80:
        advice.append({
            "severity": "High",
            "title": "Heavy swap utilization",
            "observation": (
                f"Swap usage is {swap:.1f}%. "
                "Inspect whether the system is experiencing memory pressure."
            ),
            "possible_causes": [
                "Insufficient available RAM",
                "Memory-intensive applications",
            ],
            "recommended_actions": [
                "Run `free -h` to inspect RAM and swap.",
                "Identify memory-intensive processes using `top`.",
                "Check whether the system is actively swapping and becoming slow.",
                "Do not disable swap as a quick fix.",
            ],
        })

    # --------------------------------------------------
    # 4. Disk diagnosis
    # --------------------------------------------------

    if disk is not None and disk >= 90:
        advice.append({
            "severity": "High",
            "title": "Disk space nearly exhausted",
            "observation": (
                f"Disk usage is {disk:.1f}%. "
                "Check available filesystem space."
            ),
            "possible_causes": [
                "Large files or application logs",
                "Temporary files accumulating",
                "Insufficient filesystem capacity",
            ],
            "recommended_actions": [
                "Run `df -h` to inspect filesystem space.",
                "Run `du -xhd1 ~ 2>/dev/null | sort -h` "
                "to find large directories in your home folder.",
                "Review files before deleting anything.",
                "Avoid deleting system files or logs without understanding "
                "their purpose.",
            ],
        })

    # --------------------------------------------------
    # 5. Disk activity diagnosis
    # --------------------------------------------------

    if (
        disk_read is not None
        and disk_write is not None
        and (disk_read + disk_write) > 50 * 1024 * 1024
    ):
        advice.append({
            "severity": "Medium",
            "title": "High disk throughput",
            "observation": (
                "Combined disk read and write throughput exceeds "
                "50 MiB/s in the latest sample."
            ),
            "possible_causes": [
                "Large file transfers",
                "Data processing or backups",
                "An application performing intensive disk I/O",
            ],
            "recommended_actions": [
                "Check whether a backup, download, or data-processing task "
                "is running.",
                "Use `iotop` if installed to inspect disk I/O by process.",
                "Compare disk activity across multiple samples before "
                "concluding that the activity is abnormal.",
            ],
        })

    # --------------------------------------------------
    # 6. Network diagnosis
    # --------------------------------------------------

    if network_in is not None and network_out is not None:
        total_network = network_in + network_out

        if total_network > 100 * 1024 * 1024:
            advice.append({
                "severity": "Medium",
                "title": "Very high network throughput",
                "observation": (
                    "Combined incoming and outgoing traffic exceeds "
                    "100 MiB/s in the latest sample."
                ),
                "possible_causes": [
                    "Large downloads or uploads",
                    "Data synchronization or backup",
                    "A network-intensive application",
                ],
                "recommended_actions": [
                    "Check whether a known download, upload, or backup is running.",
                    "Use `ip -s link` to inspect interface statistics.",
                    "Investigate the responsible process if the traffic is unexpected.",
                ],
            })

    if (
        network_errors is not None
        and network_errors > 0
    ):
        advice.append({
            "severity": "Medium",
            "title": "Network errors reported",
            "observation": (
                f"The latest network error counter is {network_errors:g}."
            ),
            "possible_causes": [
                "Network interface problems",
                "Driver or connectivity issues",
            ],
            "recommended_actions": [
                "Run `ip -s link` to inspect network interface counters.",
                "Compare the error count with earlier samples to see whether "
                "the counter is increasing.",
                "Check system logs for related network messages.",
            ],
        })

    if (
        network_drops is not None
        and network_drops > 0
    ):
        advice.append({
            "severity": "Medium",
            "title": "Network packets dropped",
            "observation": (
                f"The latest network drop counter is {network_drops:g}."
            ),
            "possible_causes": [
                "Interface congestion",
                "Driver or virtual network interface issues",
            ],
            "recommended_actions": [
                "Run `ip -s link` and inspect dropped packet counters.",
                "Compare the counter with earlier samples.",
                "Check whether the issue coincides with high network traffic.",
            ],
        })

    # --------------------------------------------------
    # 7. System load diagnosis
    # --------------------------------------------------

    if load is not None:
        import os

        cpu_count = os.cpu_count() or 1

        if load > cpu_count * 2:
            advice.append({
                "severity": "Medium",
                "title": "High system load",
                "observation": (
                    f"The 1-minute load average is {load:.2f}, "
                    f"and the system reports {cpu_count} logical CPUs."
                ),
                "possible_causes": [
                    "Many runnable processes",
                    "CPU contention",
                    "Tasks waiting for system resources",
                ],
                "recommended_actions": [
                    "Run `uptime` to inspect load averages.",
                    "Run `top` to inspect running processes.",
                    "Compare the load average with CPU usage and disk activity.",
                ],
            })

    # --------------------------------------------------
    # 8. System log diagnosis
    # --------------------------------------------------

    system_logs = system_logs or []

    recent_error_logs = []

    for entry in system_logs:
        try:
            priority = int(entry.get("priority", 7))
        except (TypeError, ValueError):
            priority = 7

        message = str(entry.get("message", "")).strip()

        # systemd journal priorities:
        # 0 emergency, 1 alert, 2 critical, 3 error,
        # 4 warning, 5 notice, 6 informational, 7 debug.
        if priority <= 3 and message:
            recent_error_logs.append({
                "priority": priority,
                "unit": entry.get("unit", "Unknown service"),
                "message": message,
            })

    if recent_error_logs:
        examples = recent_error_logs[-3:]

        advice.append({
            "severity": "High",
            "title": "High-priority system log events",
            "observation": (
                f"{len(recent_error_logs)} high-priority log event(s) "
                "were found in the supplied log records."
            ),
            "possible_causes": [
                "A service failure",
                "A system component reporting an error",
                "An application or driver problem",
            ],
            "recommended_actions": [
                "Inspect the affected service and the full log message.",
                "Run `journalctl -p err -n 50 --no-pager` "
                "to review recent error-level journal entries.",
                "Check whether the same error repeats and whether a related "
                "metric also changes.",
                "Do not restart or disable a service until its role and "
                "the error are understood.",
            ],
            "log_examples": examples,
        })

    # --------------------------------------------------
    # 9. General anomaly explanation
    # --------------------------------------------------

    if is_anomaly:
        score_text = ""

        if anomaly_score is not None:
            try:
                score_text = (
                    f" The calculated anomaly score is "
                    f"{float(anomaly_score):.4f}."
                )
            except (TypeError, ValueError):
                pass

        advice.append({
            "severity": "Review",
            "title": "Unusual system behavior detected",
            "observation": (
                "Isolation Forest flagged the latest metric record "
                "as unusual compared with the patterns learned during training."
                + score_text
            ),
            "possible_causes": [
                "A temporary workload spike",
                "A resource-intensive process",
                "A combination of metric values that differs from the training data",
            ],
            "recommended_actions": [
                "Review the CPU, memory, disk, and network readings above.",
                "Compare the current readings with earlier samples.",
                "Inspect system logs around the same timestamp.",
                "Investigate the specific metrics that changed before taking action.",
            ],
        })

    # --------------------------------------------------
    # 10. No advice triggered
    # --------------------------------------------------

    if not advice:
        advice.append({
            "severity": "Info",
            "title": "No rule-based warning triggered",
            "observation": (
                "The latest metrics did not cross the current diagnostic "
                "rules' thresholds."
            ),
            "possible_causes": [
                "The observed metrics are within the configured thresholds.",
                "An unusual combination may still exist without crossing "
                "a fixed threshold.",
            ],
            "recommended_actions": [
                "Continue monitoring the system.",
                "Review the anomaly timeline for unusual patterns.",
                "Keep collecting representative normal-operation data.",
            ],
        })

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "is_anomaly": bool(is_anomaly),
        "anomaly_score": anomaly_score,
        "recommendations": advice,
    }
